#!/bin/bash

echo "$FLAG" > /flag.txt
unset FLAG


/runner -ydf /app/ydfcode