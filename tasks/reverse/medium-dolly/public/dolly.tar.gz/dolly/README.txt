to mitigate possible library / environment problems
please run inside the ubuntu container:

docker run --rm -i -v $PWD:/tmp/dolly ubuntu:22.04 /tmp/dolly/dolly

thanks
